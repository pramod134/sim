"""zone_finder.py

Build a "latest-only" zone map per symbol by combining multi-timeframe
structures already stored in spot_tf (FVGs, liquidity levels/clusters,
volume profile nodes, trend/mean references) and scoring/merging them
into confluence trade areas.

Designed for Trading Bot-DB-Strategy:
  - Reads spot_tf rows across multiple timeframes (Option A).
  - Uses CandleEngine access for formation/context/post scoring of FVGs.
  - Produces one JSON zone map per symbol (to be upserted into a single row).

This module is intentionally self-contained and conservative:
  - It does not mutate indicator_bot outputs.
  - It can run even if some fields are missing (best-effort).
  - It includes an optional Supabase REST upsert helper.
"""

from __future__ import annotations

import datetime as dt
import json
import math
import os
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import httpx


# ----------------------------- helpers ------------------------------------


def _now_utc() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def _parse_ts(ts: Any) -> Optional[dt.datetime]:
    """Parse a timestamp that may be datetime, ISO string, or None."""
    if ts is None:
        return None
    if isinstance(ts, dt.datetime):
        return ts if ts.tzinfo else ts.replace(tzinfo=dt.timezone.utc)
    if isinstance(ts, (int, float)):
        try:
            return dt.datetime.fromtimestamp(float(ts), tz=dt.timezone.utc)
        except Exception:
            return None
    if isinstance(ts, str):
        s = ts.strip()
        # allow 'Z'
        if s.endswith("Z"):
            s = s[:-1] + "+00:00"
        try:
            x = dt.datetime.fromisoformat(s)
            return x if x.tzinfo else x.replace(tzinfo=dt.timezone.utc)
        except Exception:
            return None
    return None


def _safe_float(x: Any, default: Optional[float] = None) -> Optional[float]:
    try:
        if x is None:
            return default
        return float(x)
    except Exception:
        return default


def _clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def _tf_rank(tf: str) -> int:
    """Higher is higher timeframe."""
    order = {"1m": 1, "3m": 2, "5m": 3, "15m": 4, "30m": 5, "1h": 6, "4h": 7, "1d": 8, "1w": 9}
    return order.get(tf, 0)


def _tf_multiplier(tf: str) -> float:
    return {
        "1d": 1.8,
        "4h": 1.5,
        "1h": 1.3,
        "30m": 1.15,
        "15m": 1.0,
        "5m": 0.85,
        "3m": 0.75,
        "1m": 0.7,
    }.get(tf, 1.0)


def _diversity_bonus(categories: List[str]) -> int:
    n = len(set(categories))
    return {1: 0, 2: 8, 3: 18, 4: 28}.get(n, 28)


def _anchor_bonus(anchor_tf: str) -> int:
    if anchor_tf == "1d":
        return 10
    if anchor_tf in ("4h",):
        return 8
    if anchor_tf == "1h":
        return 6
    if anchor_tf == "15m":
        return 0
    if anchor_tf == "5m":
        return -4
    return 0


def _infer_atr(candles: List[Dict[str, Any]], idx: int, period: int = 14) -> Optional[float]:
    """Use candle-provided ATR if available; else compute simple ATR."""
    if not candles:
        return None
    # Prefer enriched field if present
    for key in ("atr", "ATR", "atr14"):
        v = candles[idx].get(key)
        f = _safe_float(v)
        if f is not None and f > 0:
            return f

    start = max(1, idx - period + 1)
    trs: List[float] = []
    for i in range(start, idx + 1):
        h = float(candles[i]["high"])
        l = float(candles[i]["low"])
        prev_close = float(candles[i - 1]["close"]) if i > 0 else float(candles[i]["close"])
        tr = max(h - l, abs(h - prev_close), abs(l - prev_close))
        trs.append(tr)
    if not trs:
        return None
    return sum(trs) / len(trs)


def _find_candle_index_by_ts(candles: List[Dict[str, Any]], target_ts: dt.datetime) -> Optional[int]:
    """Best-effort match to CandleEngine candles by ts.

    CandleEngine candles use key 'ts' and are timezone-aware UTC.
    We match exact first; otherwise nearest within one bar duration.
    """
    if not candles:
        return None
    # fast path exact
    for i in range(len(candles) - 1, -1, -1):
        cts = _parse_ts(candles[i].get("ts"))
        if cts == target_ts:
            return i

    # nearest
    best_i: Optional[int] = None
    best_dt = None
    for i, c in enumerate(candles):
        cts = _parse_ts(c.get("ts"))
        if cts is None:
            continue
        diff = abs((cts - target_ts).total_seconds())
        if best_dt is None or diff < best_dt:
            best_dt = diff
            best_i = i
    return best_i


# --------------------------- config --------------------------------------


@dataclass
class ZoneFinderConfig:
    timeframes_used: Tuple[str, ...] = ("1d", "1h", "15m", "5m")
    rules_version: str = "zone_rules_v1"
    max_confluence_zones: int = 20
    max_indicator_zones_per_kind: int = 120
    vp_top_bins: int = 8
    vp_bottom_bins: int = 4
    # Merge tolerance in ATR fractions; fallback will be % of price.
    merge_atr_frac: float = 0.10
    level_atr_frac: float = 0.06
    # Eligibility
    min_score: int = 25
    require_min_tf: str = "15m"  # require at least one vote at/above this TF


# --------------------------- vote model ----------------------------------


def _vote_category(kind: str) -> str:
    if kind in ("equal_high", "equal_low", "clean_high", "clean_low", "swing_high", "swing_low"):
        return "liquidity"
    if kind == "fvg":
        return "imbalance"
    if kind in ("poc", "hvn", "lvn", "vah", "val"):
        return "auction"
    if kind in ("vwap", "ema50", "ema200"):
        return "mean"
    return "other"


def _vote_base_points(kind: str, fvg_strength_0_100: Optional[int] = None) -> float:
    """Return base points before TF multiplier."""
    if kind in ("equal_high", "equal_low"):
        return 10.0
    if kind in ("clean_high", "clean_low"):
        return 8.0
    if kind in ("swing_high", "swing_low"):
        return 6.0
    if kind == "fvg":
        if fvg_strength_0_100 is None:
            return 7.0
        # Map 0–100 to 0–10
        return float(_clamp(fvg_strength_0_100 / 10.0, 0.0, 10.0))
    if kind == "poc":
        return 8.0
    if kind == "hvn":
        return 7.0
    if kind == "lvn":
        return 6.0
    if kind in ("vah", "val"):
        return 5.0
    if kind == "vwap":
        return 4.0
    if kind == "ema200":
        return 4.0
    if kind == "ema50":
        return 3.0
    return 1.0


def _level_band(price: float, tol: float) -> Tuple[float, float]:
    return price - tol, price + tol


def _zone_mid(lo: float, hi: float) -> float:
    return (lo + hi) / 2.0


# ------------------------- FVG scoring -----------------------------------


def score_fvg_with_candles(
    *,
    candles: List[Dict[str, Any]],
    created_ts: dt.datetime,
    zone_low: float,
    zone_high: float,
    filled: bool,
    pre_window: int = 15,
    post_window: int = 10,
) -> Dict[str, Any]:
    """Compute FVG strength 0–100.

    NOTE: indicator_calc1.compute_fvgs stores created_ts = c3.ts (3rd candle).
    The displacement/impulse is typically c2 (one candle before c3). We score
    formation using c2 when available, otherwise c3.
    """
    if filled:
        return {
            "strength": 0,
            "maturity": "consumed",
            "basis": "filled",
            "components": {"formation": 0, "context": 0, "post": 0},
        }

    idx = _find_candle_index_by_ts(candles, created_ts)
    if idx is None:
        # fallback: minimal
        return {
            "strength": 50,
            "maturity": "new",
            "basis": "timestamp_fallback",
            "components": {"formation": 20, "context": 15, "post": None},
        }

    # c3 is idx; displacement candle often idx-1
    c3 = candles[idx]
    c2 = candles[idx - 1] if idx - 1 >= 0 else c3
    pre_end = idx - 1
    pre_start = max(0, pre_end - pre_window)
    pre = candles[pre_start:pre_end] if pre_end > pre_start else []
    post = candles[idx + 1 : idx + 1 + post_window]

    # Helpers
    def body(c: Dict[str, Any]) -> float:
        return abs(float(c["close"]) - float(c["open"]))

    def rng(c: Dict[str, Any]) -> float:
        return max(float(c["high"]) - float(c["low"]), 1e-9)

    # ---------------- formation (0-40) ----------------
    avg_body = (sum(body(x) for x in pre) / len(pre)) if pre else body(c2)
    avg_body = max(avg_body, 1e-9)
    b_ratio = body(c2) / avg_body
    if b_ratio >= 1.5:
        disp = 20
    elif b_ratio >= 1.2:
        disp = 14
    elif b_ratio >= 1.0:
        disp = 10
    else:
        disp = 5

    atr = _infer_atr(candles, idx)
    if atr is None or atr <= 0:
        # use avg range as proxy
        avg_r = (sum(rng(x) for x in pre) / len(pre)) if pre else rng(c2)
        atr = max(avg_r, 1e-9)
    r_ratio = rng(c2) / atr
    if r_ratio >= 1.3:
        rex = 10
    elif r_ratio >= 1.1:
        rex = 6
    else:
        rex = 3

    # wick structure: reward cleaner impulse
    o2, h2, l2, c2v = float(c2["open"]), float(c2["high"]), float(c2["low"]), float(c2["close"])
    upper_w = max(h2 - max(o2, c2v), 0.0)
    lower_w = max(min(o2, c2v) - l2, 0.0)
    b2 = abs(c2v - o2)
    # dominant wick against direction weakens
    if b2 <= 1e-9:
        wick_score = 2
    else:
        wick_against = max(upper_w, lower_w)
        wick_ratio = wick_against / b2
        if wick_ratio <= 0.5:
            wick_score = 10
        elif wick_ratio <= 1.0:
            wick_score = 6
        else:
            wick_score = 2

    formation = int(_clamp(disp + rex + wick_score, 0, 40))

    # ---------------- context (0-30) ----------------
    # compression: compare last 5 ranges to prior 10
    context = 0
    if len(pre) >= 10:
        last5 = pre[-5:]
        prev10 = pre[-15:-5] if len(pre) >= 15 else pre[:-5]
        avg_last5 = sum(rng(x) for x in last5) / len(last5)
        avg_prev = sum(rng(x) for x in prev10) / len(prev10) if prev10 else avg_last5
        if avg_prev > 1e-9:
            comp_ratio = avg_last5 / avg_prev
            if comp_ratio <= 0.75:
                context += 10
            elif comp_ratio <= 0.90:
                context += 5

    # liquidity sweep bonus (lightweight): did c2 take previous 3 highs/lows then close opposite?
    # This is a heuristic; full sweep detection already exists elsewhere.
    if len(pre) >= 3:
        ph = max(float(x["high"]) for x in pre[-3:])
        pl = min(float(x["low"]) for x in pre[-3:])
        took_high = float(c2["high"]) > ph
        took_low = float(c2["low"]) < pl
        if took_high or took_low:
            context += 10

    # cap context
    context = int(_clamp(context, 0, 30))

    # ---------------- post (0-30, optional) ----------------
    # find first touch
    post_score: Optional[int] = None
    maturity = "new"
    if post:
        touch_i: Optional[int] = None
        for k, cj in enumerate(post):
            hj, lj = float(cj["high"]), float(cj["low"])
            if not (hj < zone_low or lj > zone_high):
                touch_i = k
                break
        if touch_i is None:
            # untouched
            post_score = None
            maturity = "new"
        else:
            maturity = "tested"
            cj = post[touch_i]
            hj, lj = float(cj["high"]), float(cj["low"])
            # penetration depth
            z_w = max(zone_high - zone_low, 1e-9)
            pen = (min(hj, zone_high) - max(lj, zone_low)) / z_w
            # deeper penetration => weaker
            if pen <= 0.25:
                pen_pts = 10
            elif pen <= 0.60:
                pen_pts = 6
            else:
                pen_pts = 2

            # reaction: within next 3 candles move away by >= 0.5*z_w
            move_pts = 0
            after = post[touch_i + 1 : touch_i + 4]
            if after:
                # measure distance of closes from zone
                best = 0.0
                for ak in after:
                    cl = float(ak["close"])
                    if cl > zone_high:
                        dist = cl - zone_high
                    elif cl < zone_low:
                        dist = zone_low - cl
                    else:
                        dist = 0.0
                    best = max(best, dist)
                if best >= 0.5 * z_w:
                    move_pts = 10
                    maturity = "validated"
                elif best >= 0.25 * z_w:
                    move_pts = 5
                else:
                    move_pts = 0

            # touch penalty: later touches will be handled at zone-cluster level
            post_score = int(_clamp(pen_pts + move_pts, 0, 30))

    components = {"formation": formation, "context": context, "post": post_score}

    if post_score is None:
        raw = formation + context
        strength = int(round(raw / 70.0 * 100.0))
        basis = "formation_context_only"
    else:
        raw = formation + context + post_score
        strength = int(_clamp(raw, 0, 100))
        basis = "full"

    return {
        "strength": int(_clamp(strength, 0, 100)),
        "maturity": maturity,
        "basis": basis,
        "components": components,
    }


# --------------------- extraction: spot_tf -> votes ------------------------


def _extract_fvg_votes(
    *,
    symbol: str,
    tf: str,
    spot_row: Dict[str, Any],
    candles: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    fvgs = spot_row.get("fvgs") or []
    if not isinstance(fvgs, list):
        return out
    for f in fvgs:
        if not isinstance(f, dict):
            continue
        low = _safe_float(f.get("low"))
        high = _safe_float(f.get("high"))
        if low is None or high is None:
            continue
        filled = bool(f.get("filled"))
        created_ts = _parse_ts(f.get("created_ts"))
        if created_ts is None:
            continue

        score_info = score_fvg_with_candles(
            candles=candles,
            created_ts=created_ts,
            zone_low=min(low, high),
            zone_high=max(low, high),
            filled=filled,
        )
        strength = int(score_info["strength"])
        if strength <= 0:
            continue
        out.append(
            {
                "symbol": symbol,
                "tf": tf,
                "kind": "fvg",
                "category": "imbalance",
                "low": float(min(low, high)),
                "high": float(max(low, high)),
                "direction": f.get("direction"),
                "created_ts": created_ts.isoformat(),
                "filled": filled,
                "last_touch_ts": f.get("last_touch_ts"),
                "strength": strength,
                "maturity": score_info.get("maturity"),
                "strength_basis": score_info.get("basis"),
                "strength_components": score_info.get("components"),
            }
        )
    return out


def _extract_liquidity_votes(symbol: str, tf: str, spot_row: Dict[str, Any]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    liq = spot_row.get("liquidity") or {}
    if not isinstance(liq, dict):
        return out

    def add_level(kind: str, price_key: str, src: Any):
        if not isinstance(src, list):
            return
        for it in src:
            if not isinstance(it, dict):
                continue
            p = _safe_float(it.get(price_key) or it.get("price"))
            if p is None:
                continue
            out.append(
                {
                    "symbol": symbol,
                    "tf": tf,
                    "kind": kind,
                    "category": "liquidity",
                    "price": float(p),
                    "state": it.get("state"),
                    "formed_ts": it.get("formed_ts") or it.get("swing_ts"),
                    "touches_ts": it.get("touches_ts"),
                    "wick_count": it.get("wick_count"),
                    "break_count": it.get("break_count"),
                }
            )

    add_level("equal_high", "price", liq.get("equal_highs") or [])
    add_level("equal_low", "price", liq.get("equal_lows") or [])
    add_level("clean_high", "price", liq.get("clean_highs") or [])
    add_level("clean_low", "price", liq.get("clean_lows") or [])

    # swing levels: liquidity.levels entries may have type/swing
    levels = liq.get("levels") or []
    if isinstance(levels, list):
        for lv in levels:
            if not isinstance(lv, dict):
                continue
            p = _safe_float(lv.get("price"))
            if p is None:
                continue
            lvl_type = (lv.get("type") or lv.get("level_type") or lv.get("side") or "").lower()
            if "high" in lvl_type:
                kind = "swing_high"
            elif "low" in lvl_type:
                kind = "swing_low"
            else:
                # fallback: if price above last close maybe high; but keep generic
                kind = "swing"
            out.append(
                {
                    "symbol": symbol,
                    "tf": tf,
                    "kind": kind,
                    "category": "liquidity",
                    "price": float(p),
                    "state": lv.get("state"),
                    "swing_ts": lv.get("swing_ts") or lv.get("formed_ts"),
                    "touches_ts": lv.get("touches_ts"),
                    "wick_count": lv.get("wick_count"),
                    "break_count": lv.get("break_count"),
                }
            )

    return out


def _extract_vp_votes(symbol: str, tf: str, spot_row: Dict[str, Any], cfg: ZoneFinderConfig) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    vp = spot_row.get("volume_profile") or {}
    if not isinstance(vp, dict):
        return out

    poc = vp.get("poc")
    if isinstance(poc, dict):
        p = _safe_float(poc.get("price"))
        if p is not None:
            out.append({"symbol": symbol, "tf": tf, "kind": "poc", "category": "auction", "price": float(p), "volume": poc.get("volume")})

    bins = vp.get("bins") or []
    if isinstance(bins, list) and bins:
        parsed: List[Tuple[float, float]] = []
        for b in bins:
            if not isinstance(b, dict):
                continue
            price = _safe_float(b.get("price"))
            vol = _safe_float(b.get("volume"))
            if price is None or vol is None:
                continue
            parsed.append((price, vol))
        if parsed:
            parsed_sorted = sorted(parsed, key=lambda x: x[1], reverse=True)
            top = parsed_sorted[: cfg.vp_top_bins]
            for rank, (price, vol) in enumerate(top, start=1):
                out.append({"symbol": symbol, "tf": tf, "kind": "hvn", "category": "auction", "price": float(price), "volume": float(vol), "rank": rank})

            bottom = sorted(parsed, key=lambda x: x[1])[: cfg.vp_bottom_bins]
            for rank, (price, vol) in enumerate(bottom, start=1):
                out.append({"symbol": symbol, "tf": tf, "kind": "lvn", "category": "auction", "price": float(price), "volume": float(vol), "rank": rank})

    return out


def _extract_mean_votes(symbol: str, tf: str, spot_row: Dict[str, Any]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    trend = spot_row.get("trend") or {}
    if isinstance(trend, dict):
        for k in ("ema50", "ema200"):
            v = _safe_float(trend.get(k))
            if v is not None:
                out.append({"symbol": symbol, "tf": tf, "kind": k, "category": "mean", "price": float(v)})

    adv = spot_row.get("extras_advanced") or {}
    if isinstance(adv, dict):
        vwap = (adv.get("vwap") or {}).get("vwap_rth") if isinstance(adv.get("vwap"), dict) else None
        v = _safe_float(vwap)
        if v is not None:
            out.append({"symbol": symbol, "tf": tf, "kind": "vwap", "category": "mean", "price": float(v)})
    return out


# --------------------- normalize votes to zones ----------------------------


def _vote_to_zone(
    vote: Dict[str, Any],
    *,
    tol: float,
) -> Tuple[float, float]:
    if "low" in vote and "high" in vote:
        lo = float(vote["low"])
        hi = float(vote["high"])
        # expand slightly for merge robustness
        return lo - tol * 0.25, hi + tol * 0.25
    p = _safe_float(vote.get("price"))
    if p is None:
        # fallback
        return 0.0, 0.0
    return _level_band(float(p), tol)


def _vote_points(vote: Dict[str, Any]) -> float:
    tf = vote.get("tf") or ""
    kind = vote.get("kind") or ""
    base = _vote_base_points(kind, vote.get("strength"))
    pts = base * _tf_multiplier(str(tf))

    # State modifiers
    state = (vote.get("state") or "").lower()
    if state == "broken":
        pts *= 0.2

    # Touch penalty if available
    touches = vote.get("touches_ts")
    if isinstance(touches, list):
        n = len(touches)
        if n <= 1:
            pass
        elif n <= 3:
            pts *= 0.85
        else:
            pts *= 0.65

    return float(pts)


# --------------------- clustering / confluence -----------------------------


def _cluster_votes(
    *,
    votes: List[Dict[str, Any]],
    merge_tol: float,
) -> List[Dict[str, Any]]:
    """Merge overlapping vote-zones into confluence clusters."""
    items: List[Tuple[float, float, float, Dict[str, Any]]] = []
    for v in votes:
        # per-vote tol can be adjusted later; use merge_tol here
        zlo, zhi = _vote_to_zone(v, tol=merge_tol)
        mid = _zone_mid(zlo, zhi)
        items.append((zlo, zhi, mid, v))
    if not items:
        return []
    items.sort(key=lambda x: x[2])

    clusters: List[Dict[str, Any]] = []
    cur_lo, cur_hi, _, _ = items[0]
    cur_votes: List[Dict[str, Any]] = [items[0][3]]
    for zlo, zhi, _, v in items[1:]:
        if zlo <= cur_hi + merge_tol:
            cur_hi = max(cur_hi, zhi)
            cur_lo = min(cur_lo, zlo)
            cur_votes.append(v)
        else:
            clusters.append({"zone_low": cur_lo, "zone_high": cur_hi, "votes": cur_votes})
            cur_lo, cur_hi = zlo, zhi
            cur_votes = [v]
    clusters.append({"zone_low": cur_lo, "zone_high": cur_hi, "votes": cur_votes})
    return clusters


def _score_cluster(cluster: Dict[str, Any]) -> Dict[str, Any]:
    votes = cluster.get("votes") or []
    if not isinstance(votes, list) or not votes:
        return {**cluster, "score": 0, "categories": [], "source_tfs": [], "anchor_tf": None, "side": "unknown"}

    categories = [_vote_category(v.get("kind", "")) for v in votes]
    tfs = [str(v.get("tf")) for v in votes if v.get("tf")]
    anchor_tf = max(tfs, key=_tf_rank) if tfs else ""

    pts = sum(_vote_points(v) for v in votes)
    pts += _diversity_bonus(categories)
    pts += _anchor_bonus(anchor_tf)

    # Mean-only guard (zones must have at least one of liquidity/imbalance/auction)
    has_core = any(c in ("liquidity", "imbalance", "auction") for c in categories)
    if not has_core:
        pts = 0

    score = int(_clamp(pts, 0, 100))

    # Side bias heuristic
    # If strongest liquidity is high -> short, low -> long; else use FVG direction.
    side = "unknown"
    liq_votes = [v for v in votes if _vote_category(v.get("kind", "")) == "liquidity"]
    if liq_votes:
        # pick highest point liquidity vote
        best = max(liq_votes, key=_vote_points)
        k = str(best.get("kind"))
        if "high" in k:
            side = "short"
        elif "low" in k:
            side = "long"
    if side == "unknown":
        fvg_votes = [v for v in votes if v.get("kind") == "fvg"]
        if fvg_votes:
            best = max(fvg_votes, key=lambda x: x.get("strength", 0))
            if best.get("direction") == "bear":
                side = "short"
            elif best.get("direction") == "bull":
                side = "long"

    return {
        **cluster,
        "mid": _zone_mid(float(cluster["zone_low"]), float(cluster["zone_high"])),
        "score": score,
        "categories": sorted(set(categories)),
        "source_tfs": sorted(set(tfs), key=_tf_rank),
        "anchor_tf": anchor_tf,
        "side": side,
    }


def _cluster_eligible(cluster: Dict[str, Any], cfg: ZoneFinderConfig) -> bool:
    if int(cluster.get("score", 0)) < cfg.min_score:
        return False
    cats = cluster.get("categories") or []
    if len(set(cats)) < 2:
        return False
    # require at least one TF >= require_min_tf
    req_rank = _tf_rank(cfg.require_min_tf)
    tfs = cluster.get("source_tfs") or []
    if not any(_tf_rank(tf) >= req_rank for tf in tfs):
        return False
    return True


# ------------------------ public API --------------------------------------


def build_symbol_zone_map(
    *,
    symbol: str,
    spot_tf_rows: List[Dict[str, Any]],
    candle_engine: Any,
    cfg: Optional[ZoneFinderConfig] = None,
) -> Dict[str, Any]:
    """Build the latest zone map for a symbol (Option A).

    Args:
        symbol: e.g. 'SPY'
        spot_tf_rows: all spot_tf rows for this symbol across timeframes
        candle_engine: instance of CandleEngine (must expose get_candles)
        cfg: configuration

    Returns:
        dict suitable for writing into a single "latest" row per symbol.
    """
    cfg = cfg or ZoneFinderConfig()
    sym = symbol.upper()

    # Keep only desired timeframes
    rows = [r for r in spot_tf_rows if str(r.get("timeframe", "")).lower() in set(cfg.timeframes_used)]
    # if a timeframe is missing, we still proceed

    asof_candidates: List[dt.datetime] = []
    for r in rows:
        ts = _parse_ts(r.get("last_updated"))
        if ts:
            asof_candidates.append(ts)
    asof_ts = max(asof_candidates) if asof_candidates else _now_utc()

    zones_by_indicator: Dict[str, Any] = {
        "fvg": [],
        "equal_high": [],
        "equal_low": [],
        "clean_high": [],
        "clean_low": [],
        "swing": [],
        "vp": {"poc": [], "hvn": [], "lvn": []},
        "mean": {"vwap": [], "ema50": [], "ema200": []},
    }

    all_votes: List[Dict[str, Any]] = []
    merge_tols: List[float] = []

    for r in rows:
        tf = str(r.get("timeframe")).lower()
        candles = candle_engine.get_candles(sym, tf) if candle_engine is not None else []
        last_price = None
        if candles:
            last_price = _safe_float(candles[-1].get("close"))

        # tolerance derived from ATR or price
        tol = None
        if candles:
            atr = _infer_atr(candles, len(candles) - 1)
            if atr and atr > 0:
                tol = float(cfg.level_atr_frac * atr)
        if tol is None:
            if last_price is not None:
                tol = float(0.0003 * last_price)  # 3 bps
            else:
                tol = 0.05
        merge_tol = max(tol, float(cfg.merge_atr_frac * (atr if candles and atr else tol)))
        merge_tols.append(merge_tol)

        # Extract votes
        fvg_votes = _extract_fvg_votes(symbol=sym, tf=tf, spot_row=r, candles=candles)
        liq_votes = _extract_liquidity_votes(sym, tf, r)
        vp_votes = _extract_vp_votes(sym, tf, r, cfg)
        mean_votes = _extract_mean_votes(sym, tf, r)

        # Fill indicator buckets (dedupe later)
        zones_by_indicator["fvg"].extend(fvg_votes)
        for v in liq_votes:
            k = v.get("kind")
            if k in ("equal_high", "equal_low", "clean_high", "clean_low"):
                zones_by_indicator[k].append(v)
            else:
                zones_by_indicator["swing"].append(v)
        for v in vp_votes:
            zones_by_indicator["vp"].setdefault(v["kind"], []).append(v)
        for v in mean_votes:
            zones_by_indicator["mean"].setdefault(v["kind"], []).append(v)

        all_votes.extend(fvg_votes)
        all_votes.extend(liq_votes)
        all_votes.extend(vp_votes)
        all_votes.extend(mean_votes)

    # Trim indicator arrays to keep row size sane
    def _trim(lst: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        # Sort by a reasonable key then keep top N
        def key(x):
            if x.get("kind") == "fvg":
                return x.get("strength", 0)
            touches = x.get("touches_ts")
            tc = len(touches) if isinstance(touches, list) else 0
            return 100 - tc
        lst2 = sorted(lst, key=key, reverse=True)
        return lst2[: cfg.max_indicator_zones_per_kind]

    zones_by_indicator["fvg"] = _trim(zones_by_indicator["fvg"])
    for k in ("equal_high", "equal_low", "clean_high", "clean_low", "swing"):
        zones_by_indicator[k] = _trim(zones_by_indicator[k])
    for k in ("poc", "hvn", "lvn"):
        zones_by_indicator["vp"][k] = _trim(zones_by_indicator["vp"].get(k, []))
    for k in ("vwap", "ema50", "ema200"):
        zones_by_indicator["mean"][k] = _trim(zones_by_indicator["mean"].get(k, []))

    # Build confluence zones
    merge_tol = float(max(merge_tols) if merge_tols else 0.05)
    clusters = _cluster_votes(votes=all_votes, merge_tol=merge_tol)
    scored = [_score_cluster(c) for c in clusters]
    eligible = [c for c in scored if _cluster_eligible(c, cfg)]
    eligible.sort(key=lambda x: x.get("score", 0), reverse=True)
    eligible = eligible[: cfg.max_confluence_zones]

    zone_map = {
        "symbol": sym,
        "asof_ts": asof_ts.isoformat(),
        "timeframes_used": list(cfg.timeframes_used),
        "rules_version": cfg.rules_version,
        "zones_by_indicator": zones_by_indicator,
        "confluence_zones": eligible,
        "meta": {
            "merge_tol": merge_tol,
            "total_votes": len(all_votes),
            "total_clusters": len(scored),
            "eligible_clusters": len(eligible),
        },
    }
    return zone_map


# ------------------------ optional: Supabase upsert ------------------------


async def upsert_symbol_zone_map(
    *,
    zone_map: Dict[str, Any],
    table: str = "symbol_zone_map",
    supabase_url: Optional[str] = None,
    supabase_key: Optional[str] = None,
    timeout_s: float = 20.0,
) -> None:
    """Upsert latest zone map into Supabase via REST.

    Expects table with primary key on 'symbol'.
    """
    supabase_url = supabase_url or os.getenv("SUPABASE_URL")
    supabase_key = supabase_key or os.getenv("SUPABASE_SERVICE_ROLE_KEY") or os.getenv("SUPABASE_SERVICE_KEY") or os.getenv("SUPABASE_KEY")
    if not supabase_url or not supabase_key:
        raise RuntimeError("Missing SUPABASE_URL or SUPABASE_*_KEY env vars")

    url = f"{supabase_url.rstrip('/')}/rest/v1/{table}"
    headers = {
        "apikey": supabase_key,
        "Authorization": f"Bearer {supabase_key}",
        "Content-Type": "application/json",
        "Prefer": "resolution=merge-duplicates",  # upsert behavior
    }

    # Keep only columns expected in latest-only table
    payload = {
        "symbol": zone_map.get("symbol"),
        "asof_ts": zone_map.get("asof_ts"),
        "timeframes_used": zone_map.get("timeframes_used"),
        "rules_version": zone_map.get("rules_version"),
        "zones_by_indicator": zone_map.get("zones_by_indicator"),
        "confluence_zones": zone_map.get("confluence_zones"),
        "meta": zone_map.get("meta"),
    }

    async with httpx.AsyncClient(timeout=timeout_s) as client:
        r = await client.post(url, headers=headers, params={"on_conflict": "symbol"}, content=json.dumps(payload))
        if r.status_code not in (200, 201, 204):
            raise RuntimeError(f"Supabase upsert failed ({r.status_code}): {r.text}")
