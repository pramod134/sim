import os
import asyncio
import datetime as dt
from typing import Dict, List, Any, Optional

import httpx
from zoneinfo import ZoneInfo

# Import your existing Alpaca market data module
import market_data  # make sure this is on PYTHONPATH

EASTERN = ZoneInfo("America/New_York")

# Timeframes we manage live
LIVE_TFS = ["1m", "3m", "5m", "15m", "1h"]

# ---- RTH Helpers -----------------------------------------------------------

def is_rth_timestamp(ts_utc: dt.datetime) -> bool:
    """
    Return True if timestamp is within US RTH (Mon–Fri, 09:30–16:00 ET).
    """
    ts_et = ts_utc.astimezone(EASTERN)
    if ts_et.weekday() > 4:  # Sat/Sun
        return False
    t = ts_et.time()
    # 09:30 <= t < 16:00
    if t.hour < 9 or t.hour > 16:
        return False
    if t.hour == 9 and t.minute < 30:
        return False
    if t.hour == 16:
        # any time at/after 16:00:00 is not RTH
        if t.minute > 0 or t.second > 0:
            return False
        return False
    return True


def is_rth_now() -> bool:
    """
    Check whether 'now' (in ET) is inside regular trading hours.
    Used to decide whether to call Twelve Data at all.
    """
    now_utc = dt.datetime.now(dt.timezone.utc)
    return is_rth_timestamp(now_utc)


# ---- Bucket helpers for aggregation ---------------------------------------

def _bucket_start_3m(ts_et: dt.datetime) -> dt.datetime:
    minute = (ts_et.minute // 3) * 3
    return ts_et.replace(minute=minute, second=0, microsecond=0)

def _bucket_start_5m(ts_et: dt.datetime) -> dt.datetime:
    minute = (ts_et.minute // 5) * 5
    return ts_et.replace(minute=minute, second=0, microsecond=0)

def _bucket_start_15m(ts_et: dt.datetime) -> dt.datetime:
    minute = (ts_et.minute // 15) * 15
    return ts_et.replace(minute=minute, second=0, microsecond=0)

def _bucket_start_1h(ts_et: dt.datetime) -> dt.datetime:
    """
    Align hourly bars to 09:30, 10:30, 11:30, ...
    Using minutes since 09:30 as anchor.
    """
    open_minutes = 9 * 60 + 30
    total_minutes = ts_et.hour * 60 + ts_et.minute
    delta = max(0, total_minutes - open_minutes)
    bucket_index = delta // 60
    bucket_start_total = open_minutes + bucket_index * 60
    hour = bucket_start_total // 60
    minute = bucket_start_total % 60
    return ts_et.replace(hour=hour, minute=minute, second=0, microsecond=0)


def bucket_start(ts_utc: dt.datetime, tf: str) -> dt.datetime:
    """
    Given a UTC timestamp and timeframe key ('3m','5m','15m','1h'),
    return the bucket start as a UTC datetime.
    """
    ts_et = ts_utc.astimezone(EASTERN)
    if tf == "3m":
        start_et = _bucket_start_3m(ts_et)
    elif tf == "5m":
        start_et = _bucket_start_5m(ts_et)
    elif tf == "15m":
        start_et = _bucket_start_15m(ts_et)
    elif tf == "1h":
        start_et = _bucket_start_1h(ts_et)
    else:
        raise ValueError(f"Unsupported timeframe for bucketing: {tf}")
    return start_et.astimezone(dt.timezone.utc)


# ---- Candle Engine --------------------------------------------------------

class CandleEngine:
    """
    Maintains RTH-only candles for multiple symbols and timeframes, using:
      - Alpaca (via market_data) for baseline history
      - Twelve Data 1min for live updates every few minutes
    """

    def __init__(self, twelve_data_api_key: str, symbols: List[str]):
        self.td_api_key = twelve_data_api_key
        self.symbols = sorted({s.upper() for s in symbols if s.strip()})

        # candles[symbol][tf] -> list of candle dicts
        self.candles: Dict[str, Dict[str, List[Dict[str, Any]]]] = {}
        # latest_ts[symbol][tf] -> dt.datetime of last candle
        self.latest_ts: Dict[str, Dict[str, Optional[dt.datetime]]] = {}

    # ---- Initialization from Alpaca --------------------------------------

    async def initialize_from_alpaca(self) -> None:
        """
        For all symbols, fetch baseline candles from Alpaca via market_data.
        Populates candles and latest_ts for all managed timeframes.
        """
        if not self.symbols:
            print("CandleEngine.initialize_from_alpaca: No symbols provided.")
            return

        async with httpx.AsyncClient(timeout=30.0) as client:
            # We call per symbol (simpler and safer)
            for sym in self.symbols:
                try:
                    data = await market_data.fetch_multi_tf_candles(client, [sym])
                except Exception as e:
                    print(f"[INIT] Error fetching Alpaca candles for {sym}: {e}")
                    continue

                per_sym = data.get(sym, {})
                self.candles.setdefault(sym, {})
                self.latest_ts.setdefault(sym, {})

                for tf, c_list in per_sym.items():
                    # Store only the timeframes we care about live
                    if tf in LIVE_TFS or tf in ("1d", "1w"):
                        self.candles[sym][tf] = c_list
                        if c_list:
                            last_ts = dt.datetime.fromisoformat(c_list[-1]["ts"])
                        else:
                            last_ts = None
                        self.latest_ts[sym][tf] = last_ts

                print(f"[INIT] {sym}: "
                      + ", ".join(
                          f"{tf}={len(self.candles[sym].get(tf, []))}"
                          for tf in sorted(self.candles[sym].keys())
                      ))

    # ---- Twelve Data integration -----------------------------------------

    async def _fetch_td_1m(self, client: httpx.AsyncClient, symbol: str) -> List[Dict[str, Any]]:
        """
        Fetch last 20 1m candles from Twelve Data for a given symbol.
        Returns normalized candle dicts:
          {ts, open, high, low, close, volume}
        RTH-only (we filter by timestamp).
        """
        params = {
            "symbol": symbol,
            "interval": "1min",
            "outputsize": "20",
            "apikey": self.td_api_key,
        }
        resp = await client.get("https://api.twelvedata.com/time_series", params=params)
        resp.raise_for_status()
        data = resp.json()

        if "values" not in data:
            print(f"[TD] No 'values' in response for {symbol}: {data}")
            return []

        raw_values = data["values"]
        out: List[Dict[str, Any]] = []
        for v in raw_values:
            # Twelve Data datetime is like "2025-11-26 15:59:00"
            ts_str = v.get("datetime")
            if not ts_str:
                continue
            # Parse as naive, assume it's in exchange timezone (we'll treat as UTC then convert)
            # Better: treat as aware with UTC, then adjust; simplest is to parse and assume it's UTC.
            ts = dt.datetime.strptime(ts_str, "%Y-%m-%d %H:%M:%S")
            ts = ts.replace(tzinfo=dt.timezone.utc)

            if not is_rth_timestamp(ts):
                continue

            try:
                out.append(
                    {
                        "ts": ts.isoformat(),
                        "open": float(v["open"]),
                        "high": float(v["high"]),
                        "low": float(v["low"]),
                        "close": float(v["close"]),
                        "volume": float(v.get("volume", 0.0)),
                    }
                )
            except (KeyError, ValueError):
                continue

        # Twelve Data returns newest first; sort ascending by ts
        out.sort(key=lambda c: c["ts"])
        return out

    async def update_from_twelvedata_once(self) -> None:
        """
        Single update cycle:
          - Only runs if now is RTH (ET)
          - For each symbol:
             * fetch last 20×1m from TD
             * filter out already-known candles
             * append new 1m
             * aggregate to 3m,5m,15m,1h
        """
        if not is_rth_now():
            print("[TD] Outside RTH; skipping Twelve Data update.")
            return

        if not self.symbols:
            print("[TD] No symbols to update.")
            return

        async with httpx.AsyncClient(timeout=15.0) as client:
            for sym in self.symbols:
                try:
                    td_candles = await self._fetch_td_1m(client, sym)
                except Exception as e:
                    print(f"[TD] Error fetching Twelve Data candles for {sym}: {e}")
                    continue

                if not td_candles:
                    continue

                # Ensure structures exist
                self.candles.setdefault(sym, {})
                self.latest_ts.setdefault(sym, {})
                for tf in LIVE_TFS:
                    self.candles[sym].setdefault(tf, [])
                    self.latest_ts[sym].setdefault(tf, None)

                # Filter out 1m candles we already have
                last_1m_ts = self.latest_ts[sym]["1m"]
                new_1m = []
                for c in td_candles:
                    ts = dt.datetime.fromisoformat(c["ts"])
                    if last_1m_ts is None or ts > last_1m_ts:
                        new_1m.append(c)

                if not new_1m:
                    continue

                # Append new 1m
                self.candles[sym]["1m"].extend(new_1m)
                self.latest_ts[sym]["1m"] = dt.datetime.fromisoformat(self.candles[sym]["1m"][-1]["ts"])

                # Aggregate new 1m to higher TFs
                self._aggregate_new_1m(sym, new_1m)

                print(f"[TD] {sym}: +{len(new_1m)} new 1m candles.")

    # ---- Aggregation from 1m to higher TFs -------------------------------

    def _aggregate_new_1m(self, symbol: str, new_1m: List[Dict[str, Any]]) -> None:
        """
        Given a list of new 1m candles (already appended), update derived
        3m, 5m, 15m, 1h series for this symbol.
        """
        for c in new_1m:
            ts = dt.datetime.fromisoformat(c["ts"])
            o = c["open"]
            h = c["high"]
            l = c["low"]
            cl = c["close"]
            v = c["volume"]

            for tf in ("3m", "5m", "15m", "1h"):
                bucket_ts_utc = bucket_start(ts, tf)

                tf_list = self.candles[symbol][tf]
                if tf_list:
                    last_bar = tf_list[-1]
                    last_ts = dt.datetime.fromisoformat(last_bar["ts"])
                else:
                    last_bar = None
                    last_ts = None

                if last_bar is not None and last_ts == bucket_ts_utc:
                    # update existing bar
                    last_bar["high"] = max(last_bar["high"], h)
                    last_bar["low"] = min(last_bar["low"], l)
                    last_bar["close"] = cl
                    last_bar["volume"] += v
                elif last_ts is None or bucket_ts_utc > last_ts:
                    # new bucket: append bar
                    tf_list.append(
                        {
                            "ts": bucket_ts_utc.isoformat(),
                            "open": o,
                            "high": h,
                            "low": l,
                            "close": cl,
                            "volume": v,
                        }
                    )
                else:
                    # bucket_ts_utc < last_ts: old/corrupted data; ignore
                    continue

                # update latest_ts for that tf
                self.latest_ts[symbol][tf] = dt.datetime.fromisoformat(self.candles[symbol][tf][-1]["ts"])

    # ---- Public API -------------------------------------------------------

    def get_candles(self, symbol: str, timeframe: str) -> List[Dict[str, Any]]:
        """
        Return current candles for symbol+timeframe from in-memory cache.
        Timeframe in {'1m','3m','5m','15m','1h','1d','1w'}.
        """
        symbol = symbol.upper()
        return self.candles.get(symbol, {}).get(timeframe, [])

    # ---- Main loop --------------------------------------------------------

    async def run_loop(self, interval_seconds: int = 180) -> None:
        """
        Main loop: periodically updates from Twelve Data.
        Call this once (after initialize_from_alpaca) to keep candles live.
        """
        print("[ENGINE] Starting live update loop.")
        while True:
            try:
                await self.update_from_twelvedata_once()
            except Exception as e:
                print(f"[ENGINE] Error in update loop: {e}")

            await asyncio.sleep(interval_seconds)


# ---- Helper to get symbols from DB (you can replace this) -----------------

async def load_symbols_from_spot_tf() -> List[str]:
    """
    Placeholder: you should replace this with real DB query to Supabase:
      SELECT DISTINCT symbol FROM public.spot_tf;
    For now, return a small hard-coded list for testing.
    """
    # TODO: replace with real DB call
    return ["SPY", "AMD"]


# ---- Example entry point --------------------------------------------------

async def main():
    td_key = os.getenv("TWELVEDATA_API_KEY")
    if not td_key:
        raise RuntimeError("TWELVEDATA_API_KEY env var is required")

    symbols = await load_symbols_from_spot_tf()
    if not symbols:
        print("No symbols loaded from spot_tf; exiting.")
        return

    engine = CandleEngine(td_key, symbols)
    await engine.initialize_from_alpaca()
    await engine.run_loop(interval_seconds=180)


if __name__ == "__main__":
    asyncio.run(main())
