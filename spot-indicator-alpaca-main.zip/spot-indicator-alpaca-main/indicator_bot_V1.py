import os
import math
import asyncio
import datetime as dt
from typing import Any, Dict, List, Optional, Tuple

import httpx

from zone_finder import build_symbol_zone_map, upsert_symbol_zone_map

from candle_engine import CandleEngine, SUPPORTED_TFS

from indicator_calc1 import compute_all_indicators

from indicator_calc2 import compute_advanced_extras



from strategies import evaluate_strategies



EASTERN = dt.timezone(dt.timedelta(hours=-5))  # not critical, mainly for consistency


# ---------------------------------------------------------------------------
# Supabase helper: update indicators columns in spot_tf
# ---------------------------------------------------------------------------


async def update_indicators_in_spot_tf(
    symbol: str,
    timeframe: str,
    trend: Dict[str, Any],
    pivots: Dict[str, Any],
    swings: Dict[str, Any],
    structural: Dict[str, Any],
    fvgs: List[Dict[str, Any]],
    liquidity: Dict[str, Any],
    volume_profile: Dict[str, Any],
    extras: Dict[str, Any],
    extras_advanced: Optional[Dict[str, Any]],
    structure_state: Optional[str],
    strategies: Optional[List[Dict[str, Any]]] = None,
) -> None:
    """
    Patch public.spot_tf for the given symbol+timeframe with the computed indicators.

    Uses Supabase REST. Requires:
      - SUPABASE_URL
      - SUPABASE_SERVICE_ROLE_KEY or SUPABASE_SERVICE_KEY or SUPABASE_KEY
    """
    supabase_url = os.getenv("SUPABASE_URL")
    supabase_key = (
        os.getenv("SUPABASE_SERVICE_ROLE_KEY")
        or os.getenv("SUPABASE_SERVICE_KEY")
        or os.getenv("SUPABASE_KEY")
    )

    if not supabase_url or not supabase_key:
        print("[INDICATORS][DB] Skipping update: Supabase env vars missing")
        return

    endpoint = f"{supabase_url.rstrip('/')}/rest/v1/spot_tf"
    params = {
        "symbol": f"eq.{symbol}",
        "timeframe": f"eq.{timeframe}",
    }
    headers = {
        "apikey": supabase_key,
        "Authorization": f"Bearer {supabase_key}",
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Prefer": "return=minimal",
    }

    payload: Dict[str, Any] = {
        "trend": trend,
        "pivots": pivots,
        "swings": swings,
        "structural": structural,
        "fvgs": fvgs,
        "liquidity": liquidity,
        "volume_profile": volume_profile,
        "extras": extras,
        "extras_advanced": extras_advanced,
        "last_updated": dt.datetime.now(dt.timezone.utc).isoformat(),
    }

    if structure_state is not None:
        payload["structure_state"] = structure_state
    if strategies is not None:
        payload["strategies"] = strategies

    async with httpx.AsyncClient(timeout=10.0) as client:
        try:
            resp = await client.patch(
                endpoint,
                params=params,
                json=payload,
                headers=headers,
            )
            if resp.status_code >= 400:
                print(
                    f"[INDICATORS][DB] Failed to update indicators for "
                    f"{symbol} {timeframe} (status={resp.status_code})"
                )
                print(f"[INDICATORS][DB] Response text: {resp.text}")
                resp.raise_for_status()
        except httpx.HTTPError as e:
            print(f"[INDICATORS][DB] HTTP error for {symbol} {timeframe}: {e}")
        except Exception as e:
            print(f"[INDICATORS][DB] Unexpected error for {symbol} {timeframe}: {e}")


async def fetch_spot_tf_rows_for_symbol(symbol: str) -> List[Dict[str, Any]]:
    """
    Fetch all spot_tf rows for a symbol across all timeframes.
    Used by ZoneFinder to build a unified (Option A) zone map.
    """
    supabase_url = os.getenv("SUPABASE_URL")
    supabase_key = os.getenv("SUPABASE_SERVICE_ROLE_KEY") or os.getenv("SUPABASE_SERVICE_KEY") or os.getenv("SUPABASE_KEY")
    if not supabase_url or not supabase_key:
        raise RuntimeError("Missing SUPABASE_URL or SUPABASE_* key env vars")

    endpoint = f"{supabase_url.rstrip('/')}/rest/v1/spot_tf"
    headers = {
        "apikey": supabase_key,
        "Authorization": f"Bearer {supabase_key}",
        "Accept": "application/json",
    }

    params = {
        "symbol": f"eq.{symbol.upper()}",
        "select": "*",
    }

    async with httpx.AsyncClient(timeout=20.0) as client:
        r = await client.get(endpoint, headers=headers, params=params)
        if r.status_code != 200:
            raise RuntimeError(f"spot_tf fetch failed ({r.status_code}): {r.text}")
        return r.json()






# ---------------------------------------------------------------------------
# Utility helpers
# ---------------------------------------------------------------------------
async def needs_backfill_structure_state(symbol: str, timeframe: str) -> bool:
    """
    Return True if spot_tf.structure_state is NULL/empty for this symbol+timeframe.
    Used to force a one-time indicator backfill even when the last candle ts
    has not changed (e.g. after deleting/recreating spot_tf rows).
    """
    supabase_url = os.getenv("SUPABASE_URL")
    supabase_key = (
        os.getenv("SUPABASE_SERVICE_ROLE_KEY")
        or os.getenv("SUPABASE_SERVICE_KEY")
        or os.getenv("SUPABASE_KEY")
    )

    if not supabase_url or not supabase_key:
        # Can't check; don't force backfill in this case.
        return False

    endpoint = f"{supabase_url.rstrip('/')}/rest/v1/spot_tf"
    params = {
        "symbol": f"eq.{symbol}",
        "timeframe": f"eq.{timeframe}",
        "select": "structure_state",
    }
    headers = {
        "apikey": supabase_key,
        "Authorization": f"Bearer {supabase_key}",
        "Accept": "application/json",
    }

    async with httpx.AsyncClient(timeout=10.0) as client:
        try:
            resp = await client.get(endpoint, params=params, headers=headers)
            resp.raise_for_status()
            rows = resp.json() or []
        except Exception as e:
            print(
                f"[INDICATORS][DB] Failed to check structure_state for "
                f"{symbol} {timeframe}: {e}"
            )
            return False

    if not rows:
        # No row → don't force backfill here (engine should create rows first).
        return False

    ss = rows[0].get("structure_state")

    # Treat NULL, empty string, or purely whitespace as "missing"
    if ss is None:
        return True
    if isinstance(ss, str) and not ss.strip():
        return True

    return False



def _ensure_dt(ts_raw: Any) -> dt.datetime:
    """
    Try to convert whatever 'ts' is into an aware UTC datetime.
    CandleEngine usually stores ISO strings or datetime already.
    """
    if isinstance(ts_raw, dt.datetime):
        ts = ts_raw
    elif isinstance(ts_raw, str):
        try:
            ts = dt.datetime.fromisoformat(ts_raw)
        except Exception:
            ts = dt.datetime.now(dt.timezone.utc)
    else:
        ts = dt.datetime.now(dt.timezone.utc)

    if ts.tzinfo is None:
        ts = ts.replace(tzinfo=dt.timezone.utc)
    else:
        ts = ts.astimezone(dt.timezone.utc)
    return ts


def _tf_to_timedelta(tf: str) -> Optional[dt.timedelta]:
    """
    Convert a timeframe string like '1m', '5m', '15m', '1h', '1d' or plain
    digits like '5', '15', '60' into a timedelta. If we can't parse it,
    return None and the caller can fall back to existing behavior.
    """
    if not tf:
        return None

    s = str(tf).strip().lower()

    # Explicit suffixes
    if s.endswith("m"):  # minutes
        try:
            mins = int(s[:-1])
            return dt.timedelta(minutes=mins)
        except ValueError:
            return None

    if s.endswith("h"):  # hours
        try:
            hours = int(s[:-1])
            return dt.timedelta(hours=hours)
        except ValueError:
            return None

    if s.endswith("d"):  # days
        try:
            days = int(s[:-1])
            return dt.timedelta(days=days)
        except ValueError:
            return None

    # Plain digits → treat as minutes (e.g. "5", "15", "60")
    if s.isdigit():
        try:
            mins = int(s)
            return dt.timedelta(minutes=mins)
        except ValueError:
            return None

    return None



# ---------------------------------------------------------------------------
# IndicatorBot
# ---------------------------------------------------------------------------

class IndicatorBot:
    """
    Reads enriched candles from CandleEngine and keeps spot_tf indicators fresh
    for all SUPPORTED_TFS.

    v1 responsibilities:
      - For each (symbol, timeframe):
          * detect if there's a new last candle (ts changed)
          * compute:
              - trend (EMA50/EMA200 + distances + state)
              - swings (HH/HL/LH/LL pivots)
              - fvgs (simple 3-candle FVGs)
              - liquidity (levels from swings)
              - volume_profile (simple price/volume bins + POC)
              - extras (ATR, vol regime)
              - structure_state (trend + swings summary)
          * patch those into spot_tf via Supabase REST.
    """

    def __init__(
        self,
        engine: CandleEngine,
        timeframes: Optional[List[str]] = None,
    ):
        self.engine = engine
        self.timeframes = timeframes or list(SUPPORTED_TFS)
        # last_processed_ts[symbol][tf] -> datetime of last processed candle
        self.last_processed_ts: Dict[str, Dict[str, dt.datetime]] = {}


    

    # ------------------------------------------------------------------ #
    # Public loop
    # ------------------------------------------------------------------ #

    async def run_loop(self, interval_seconds: int = 60) -> None:
        """
        Periodically scan all symbols/timeframes and update indicators
        whenever a new candle has appeared.
        """
        print(f"[INDICATORS] Starting indicator bot (interval={interval_seconds}s)")

        while True:
            try:
                await self._update_all_symbols()
            except Exception as e:
                print(f"[INDICATORS] Exception in run_loop: {e}")
            await asyncio.sleep(interval_seconds)

    # ------------------------------------------------------------------ #
    # Core update logic
    # ------------------------------------------------------------------ #

    async def _update_all_symbols(self) -> None:
        symbols = getattr(self.engine, "symbols", [])
        if not symbols:
            print("[INDICATORS] No symbols in engine yet, skipping cycle")
            return


        for sym in symbols:
            sym_upper = sym.upper()
            symbol_candles = self.engine.candles.get(sym_upper, {})
            for tf in self.timeframes:
                candles = symbol_candles.get(tf)
                if not candles or len(candles) < 10:
                    # need some history before indicators are meaningful
                    continue
        
                # --------------------------------------------------
                # CLOSED-CANDLE FILTER
                # --------------------------------------------------
                tf_delta = _tf_to_timedelta(tf)
                now_utc = dt.datetime.now(dt.timezone.utc)
        
                closed_candles = candles
                if tf_delta is not None:
                    raw_last = candles[-1]
                    raw_last_ts = _ensure_dt(raw_last.get("ts"))
                    # If we haven't reached the end of this bar, it's still forming → drop it
                    if now_utc < (raw_last_ts + tf_delta):
                        closed_candles = candles[:-1]
        
                if not closed_candles or len(closed_candles) < 10:
                    # Not enough fully closed candles yet
                    continue
        
                last_candle = closed_candles[-1]
                ts_dt = _ensure_dt(last_candle.get("ts"))
                
                prev_ts = self.last_processed_ts.get(sym_upper, {}).get(tf)
                
                # NEW: check if structure_state is missing in spot_tf
                needs_backfill = await needs_backfill_structure_state(sym_upper, tf)
                
                # If we already processed this ts AND structure_state exists in DB,
                # we can safely skip. If structure_state is missing, force a recompute.
                if (not needs_backfill) and (prev_ts is not None) and (ts_dt <= prev_ts):
                    # already processed this CLOSED candle and DB has structure_state
                    continue


                session_date = last_candle.get("date_et")
                if session_date:
                    session_candles = [
                        c for c in closed_candles
                        if c.get("date_et") == session_date
                    ]
                else:
                    # fallback, should rarely happen
                    session_candles = closed_candles

                print(
                    f"[SESSION] {sym_upper} {tf} "
                    f"session_date={session_date} "
                    f"closed={len(closed_candles)} "
                    f"session_only={len(session_candles)} "
                    f"first_session_ts={session_candles[0].get('ts_et') if session_candles else None} "
                    f"last_session_ts={session_candles[-1].get('ts_et') if session_candles else None}"
                )

                
                    
                # --------------------------------------------------
                # INDICATORS ON CLOSED CANDLES ONLY
                # --------------------------------------------------
                snapshot = compute_all_indicators(closed_candles)
                advanced = compute_advanced_extras(
                    candles=closed_candles,
                    base_snapshot=snapshot,
                    htf_snapshot=None,     # later we can pass 60m snapshot here
                    session_candles=session_candles,
                )
        
                extras_advanced = advanced
        
                snapshot = compute_all_indicators(closed_candles)
                
                trend = snapshot["trend"]
                pivots = snapshot["pivots"]          # ✅ ADD THIS
                swings = snapshot["swings"]
                structural = snapshot["structural"]
                fvgs = snapshot["fvgs"]
                liquidity = snapshot["liquidity"]
                volume_profile = snapshot["volume_profile"]
                extras = snapshot["extras"]
                structure_state = snapshot["structure_state"]

        
                # cluster info from the last CLOSED candle (candle_engine writes this)
                cluster = last_candle.get("cluster") or {}
        
                # Strategies also see CLOSED candles only
                strategies = evaluate_strategies(
                    symbol=sym_upper,
                    timeframe=tf,
                    candles=closed_candles,
                    swings=swings,
                    fvgs=fvgs,
                    liquidity=liquidity,
                    trend=trend,
                    cluster=cluster,
                    volume_profile=volume_profile,
                    htf_swings=None,  # extend later if you add HTF swings
                )
        
                await update_indicators_in_spot_tf(
                    symbol=sym_upper,
                    timeframe=tf,
                    trend=trend,
                    pivots=pivots,
                    swings=swings,
                    structural=structural,
                    fvgs=fvgs,
                    liquidity=liquidity,
                    volume_profile=volume_profile,
                    extras=extras,
                    extras_advanced=extras_advanced,
                    structure_state=structure_state,
                    strategies=strategies,
                )

        
                self.last_processed_ts.setdefault(sym_upper, {})[tf] = ts_dt
                print(
                    f"[INDICATORS] Updated {sym_upper} {tf} "
                    f"(ts={ts_dt.isoformat()}, trend={trend.get('state')})"
                )
                        # ---------------- ZONE FINDER (Option A: all TFs -> one symbol map) ----------------
            try:
                spot_rows = await fetch_spot_tf_rows_for_symbol(sym_upper)

                zone_map = build_symbol_zone_map(
                    symbol=sym_upper,
                    spot_tf_rows=spot_rows,
                    candle_engine=self.engine,
                )

                # Upsert into your latest-only table
                await upsert_symbol_zone_map(
                    zone_map=zone_map,
                    table="zone_finder",
                )

                print(f"[ZONE_FINDER] Updated zone_finder row for {sym_upper}")

            except Exception as e:
                print(f"[ZONE_FINDER] Failed for {sym_upper}: {e}")






   
